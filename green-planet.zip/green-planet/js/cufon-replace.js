Cufon.replace('.site-nav li', { fontFamily: 'Bauhaus Md BT', hover:true });
Cufon.replace('h2', { fontFamily: 'Bauhaus Md BT' });